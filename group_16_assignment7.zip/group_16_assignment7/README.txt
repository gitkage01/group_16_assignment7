How to run program:
1. Run the "group_16_assignment7.pde" file in Processing.
2. Game controls are listed on the menu screen. 
3. The start button is a little finicky for some reason
   so multiple clicks may be required.
4. When in game, you can press the pause button in the top-right
   hand corner to pause the game.
5. Once the game is over, your score will be listed in the game
   over screen (score also in the GUI). You also have the opton
   to restart.
